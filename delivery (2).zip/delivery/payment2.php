<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Checkout Form</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <!--This code isn't working don't know why-->
    <link rel="stylesheet" href="https://kit.fontawesome.com/6c7dc6de0a.css" crossorigin="anonymous">
    <!--Ending of the code-->
</head>
<body>
    
<?php
include_once("pay.php");
if(isset($_POST['submit']))
{
    $card_holder=$_POST['card_holder'];
    $card_number=$_POST['card_number'];
    $expiry_date=$_POST['expiry_date'];
    $cvc=$_POST['cvc'];
    
        
        
    
        
    $query=mysqli_query($db,"insert into payment set card_holder = '$card_holder', card_number = '$card_number', expiry_date = '$expiry_date', cvc = '$cvc'");

   
     if($query)
    {

                echo "<script>alert('Payment successful');</script>";
                 echo "<script>window.location = 'payment.html';</script>";;
    }
    
    else 
    {
        echo "<script>alert('Invalid Values Inserted');</script>";
    }
}
 ?>
<!-- Contact Start -->
    <div class="container-fluid bg-secondary px-0">a
        <div class="row g-0">
            <div class="col-lg-6 py-6 px-5">
                <h1 class="display-5 mb-4">Contact For Any Queries</h1>
                <form action="" method="post">
                    <div class="row g-3">
                        <div class="col-6">
                            <div class="form-floating">
                                <input type="date" name="expiry_date" class="form-control" id="form-floating-2" placeholder="name@example.com">
                                <label for="form-floating-2">expiry_date</label>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-floating">
                                <input type="text" name="card_holder" class="form-control" id="form-floating-1" placeholder="John Doe">
                                <label for="form-floating-1">card_holder</label>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-floating">
                                <input type="email" name="card_number" class="form-control" id="form-floating-2" placeholder="name@example.com">
                                <label for="form-floating-2">card_number</label>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-floating">
                                <input type="number" name="cvc" class="form-control" id="form-floating-3" placeholder="Subject">
                                <label for="form-floating-3">cvc</label>
                            </div>
                        </div>
                        <!--<div class="col-12">
                            <div class="form-floating">
                                <textarea class="form-control" placeholder="Message" id="form-floating-4" style="height: 150px"></textarea>
                                <label for="form-floating-4">Message</label>
                            </div>
                        </div>-->
                        <input type="submit" name="submit" value="Submit">
                        </form>
            </div>
    <script src="https://code.jquery.com/jquery-3.6.3.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>

</body>
</html>
